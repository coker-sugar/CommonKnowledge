// module.js
export default () => "Hello world"
export const name = "nowcoder"